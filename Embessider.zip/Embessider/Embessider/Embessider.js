import { useState } from 'react'
import './Style.css'
import React, { Component } from "react";

import { Slider } from '@material-ui/core';
import axios from 'axios'
import { fontWeight } from '@mui/system';
import Topbar from '../../Topbar/Topbar';
import Footer from '../../footer/Footer';
import { right } from '@popperjs/core';







export const Embessider = () => {


    var [notshow,show]=useState(false);
    var [showval,notshowval]=useState(true);
    var [thank,setth]=useState(false);
    var [qestion,noqestion]=useState(true)
    var [home1,nohome1]=useState(true);
    var [sliderh,setsg]=useState('');
    // const[set2,setstate2]=useState(1);
    // const[apival,setapi]=useState('');


   

    // const sliderval=(e)=>{
    //     const value=e.target.value;
    //     setapi(value)
    // }


    const Thanks = (Props) => {
        return (
            
           
      
       <div  className={` ${Props.valthanks===false ? "d-none":""}   ${Props.hom1===false ? "d-none":""} m-0`}>
             
             <section >
      <div class=" lasts " >
        <div className='container'>

        <div class="row ">
          <div class="  d-flex  " >
            
            
          <div class=" col-sm-8 col-md-8  textcircle">
      <h4 class="h5" ><b>Hello, Ramisha!</b></h4>

      <p className='pproo' >Welcome to your Ambassador Profile</p>
    </div>
    <div className=' col-sm-4 col-md-4 '><p className='circle1 '></p> </div>

              </div></div></div>
<div className='container'>

<div class="row">
  <div class=" d-flex  circl" >
    
  <div class=" col-sm-3 col-md-3 col-lg-3 m-0 p-0 circlfloat">
    
<div class="circles " ><p className='textc '>10</p></div>
<p className='txt2 p-0 circlfloat'>Bookings Completed</p></div>

<div class=" col-sm-3 col-md-3 col-lg-3 m-0 p-0  circlfloat">

<div class="circles2 " ><p className='textc'>2</p></div>
<p className='txt2 p-0 circlfloat'> Bookings in Pipeline</p></div>
<div class=" col-sm-3 col-md-3 col-lg-3 m-0 p-0 circlfloat">
   
<div class="circles " ><p className='textc'>5,000</p></div>
<p className='txt2 p-0 circlfloat'>Commission Earned</p></div>
<div class=" col-sm-3 col-md-3 col-lg-3 m-0 p-0 circlfloat ">

<div class="circles2"><p className='textc'>1</p></div>
<p className='txt2 p-0  circlfloat'>Bookings Cancelled</p></div>

      </div></div></div></div>

    </section>

  

    
  
    
     

     <div className='container'>
            <div className='row '>

              <div className=' col-sm-12 col-sm-12 col-lg-12 d-flex mt-3'>
                    <button type="button" className='btn111' > Get Paid </button>

                    </div>
                    </div>
                    </div>

                    <div className='container'>
            <div className='row '>

              <div className=' col-sm-12 col-sm-12 col-lg-12 d-flex mt-3'>
                <a href=''  className='ltext1 col-sm-6 col-sm-6 col-lg-6 '><p style={{textDecoration:"underline"}}>Add Payment Method</p></a>
                <a href=''  className='ltext2  col-sm-6 flex-item-right col-sm-6 col-lg-6 '><p style={{textDecoration:"underline"}}>More Information</p></a>


                    </div>
                    </div>
                    </div>


  </div>
  


               
               
              
              
      )
      } 


    const Head = (props) => {
        return (
          
          <div className={` box-shadow-2 align-items-center justify-content-center  headtitle   mb-0 ${props.val===false ? "d-none":""} ${props.hom2===false ? "d-none":""}`}>
           <div className=' mb-2  ' >
      
               <h4 className='h4' style={{fontWeight:900}}> Ambassador Porgram</h4>
           </div>
           </div>  )
      }

     // Qestion Ans
     const[last, setlast]=useState(false);


    const Question = (props) => {

       const [headshow, noheadshoaw]=useState(false);
       const [questionshow, noqshow]=useState(true);

        const nextH=()=>{
            return(
                noqshow(false),
                noheadshoaw(true)
            )
        }
        

       

       return (

        <>
        
        <Thanks valthanks={headshow}/>
      < div className={` ${questionshow===false ? "d-none":""} ${props.secondval===false ? "d-none":"d-block"} ${props.qestionval===false ? "d-none":"d-block"} `}>
      <Head/>

          <div  className='d-flex flex-column align-items-center justify-content-center '>
          <div className={"w-100 px-3  container "} >
          <progress className={`w-100 progre`}  value="100" max={100} >30%</progress>
      </div>
      <div className={` align-items-center justify-content-center flex-column      `}>
           <div className='w-100 mb-2 ' >
      
               <h2  className="mb-0 headt"><strong>Become an Ambassador</strong></h2>
               <h4 className='he pb-2' style={{fontWeight:400}}>Please register to become an ambassador</h4>
           </div>
           </div> 
              <div className=' d-flex  flex-column container mt-2' >
                  <textarea className='box-shadow-2 inn pl-3 pt-2 pr-2 pb-1'  rows={1}  placeholder=' Enter Institute Name'></textarea>
              </div>
      </div>
      
    
     
      <div className='container'>
            <div className='row'>

              <div className=' col-sm-12 col-sm-12 col-lg-12 d-flex align-items-center justify-content-end mt-3 mb-5'>
                    <button type="button" className="bt22s" onClick={nextH}  >Submit </button>

                    </div>
                    </div>
                    </div>



     

      
      
       
      
      </div> </>  )
    
    }
      



      // Card

     const Base = (props) => {

        
      

            return (

      <>
             <div  className={ ` pt-0 cardse d-flex flex-column      `}>
            

      <div className={`  ${props.setfirstval===false ? "d-none":""}`}>
      <Head/>

      <div className={"container w-100 px-3 "} >
          <progress className={`w-100  progre`}  value={props.prog} max={100} >30%</progress>
      </div>
      <div className={` align-items-center justify-content-center flex-column    `}>
           <div className='w-100 mb-2  ' >
      
               <h2  className="mb-0 headt"><strong>Become an Ambassador</strong></h2>
               <h4 className='he pb-2' style={{fontWeight:400}}>Please register to become an ambassador</h4>
           </div>
           </div> 
      <div  className='align-items-center justify-content-center flex-column    '>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2 inn pl-3 pt-2 pr-2 pb-1'  rows={1}  placeholder={`${props.title1}` } ></textarea>
              </div>
      </div>
      <div  className='align-items-center justify-content-center flex-column     '>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2 inn pl-3 pt-2 pr-2 pb-1 mt-2 '  rows={1}  placeholder={`${props.title2}` }></textarea>
              </div>
      </div>
      <div  className='align-items-center justify-content-center flex-column   '>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2 inn pl-3 pt-2 pr-2 pb-1 mt-2'  rows={1}  placeholder={`${props.title3}` }></textarea>
              </div>
      </div>
      </div>

      <div className={` ${props.setfirsttval==false? "d-none": "d-Flex"}`}>
      <Head/>

      <div className={"container w-100 px-3  "} >
          <progress className={`w-100  progre`}  value={props.prog} max={100} >30%</progress>
      </div>
      <div className={` align-items-center justify-content-center flex-column   `}>
           <div className='w-100 mb-2 ml-2 ' >
      
               <h2  className="mb-0 headt">Become an Ambassador</h2>
               <h4 className='he pb-2' style={{fontWeight:400}}>Please register to become an ambassador</h4>
           </div>
           </div> 
      <div  className=' flex-column align-items-center justify-content-center '>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2 inn pl-3 pt-2 pr-2 pb-1  '  rows={1}  placeholder={`${props.title1}` } ></textarea>
              </div>
      </div>
      <div  className=' flex-column align-items-center justify-content-center '>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2  inn pl-3 pt-2 pr-2 pb-1 mt-2 '  rows={1}  placeholder={`${props.title2}` }></textarea>
              </div>
      </div>
      <div  className=' flex-column align-items-center justify-content-center'>
              <div className=' d-flex  flex-column container' >
                  <textarea className='box-shadow-2  innl pl-3 pt-2 pr-2 pb-4   mt-2'  rows={1}  placeholder={`${props.title3}` }></textarea>
              </div>
      </div>
      </div>



              
              </div>
              </>
             
             ) 
        }
            
        //Array Of Values

        const Arra=[
            {
            progress: 30,
            titl1:" Enter Name",
            titl2:"Enter Email",
            titl3:"Enter Phone Number",
},
            {
                progress: 70,
                titl1:"Enter Occupation",
                titl2:"Enter City",
                titl3:"How did you get to know about our Ambassador Program?",  
            },
            
            {}
           
        ];
    
        
    
    
    
    
        const[sets, setsstate]=useState(0);
        const[set1, setstate1]=useState(0);
        const[first, setfirst]=useState(true);
        const[firstt, setfirstt]=useState(false);
        const[second, setsecond]= useState(false);
        const[btn, setbtn]=useState(true);

        const [set15,set15v]=useState(false);
    
        
        const input=(ev)=>{
            ev.preventDefault()

            setfirst(false)
            setfirstt(true)
            if(sets==1)
            {
                setsecond(true);
                setfirstt(false)
                setbtn(false);

            }
            else{
                setsstate(sets+1);

            }

        
             
    
            
     }
        const decrement=()=>{
            setsstate(sets-1);
            set15v(false);
            setstate1(set1-1);

            set15v(false);
        }
    
    return (
    <>

   
       
            <Topbar color='#FF3D00' page='property'/>
                      
            <Base 
              val={showval}
              dis={false}
              setfirstval={first}
              setfirsttval={firstt}
             prog= {Arra[sets].progress}
              title1={Arra[sets].titl1}
              title2={Arra[sets].titl2}
              title3={Arra[sets].titl3}

              />
              
              



              <Question  secondval={second}
              />

                     
            <div className='container'>
            <div className='row '>

              <div className=' col-sm-12 col-sm-12 col-lg-12 d-flex align-items-center justify-content-end mt-3 mb-5'>
                    <button type="button" onClick={decrement} className={`bt22 ${sets===0 ? "d-none":""}   ${btn===false ? "d-none":""} `} >Previous </button>
                    <button type="button" onClick={input} className={`bt11 ${btn===false ? "d-none":""}`}>Next </button>

                    </div>
                    </div>
                    </div>
                    
                    
<Footer/>
            
       
   
     </>
  )

}
